<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.mb-5
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/1.png", data-aos="zoom-in")      
      .col-lg-8
        .bg-color-4.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/2.svg")
            .col-lg
              p.mb-0 La crianza corresponde a las acciones, actitudes y comportamientos de los padres o cuidadores sobre los niños a su cargo, en el rol de mentores, acompañantes, mediadores o titulares, en el proceso experiencial de ellos. La crianza recoge aquellos conocimientos y acciones que, de manera particular, se convierten en estrategias para educar para el bienestar, el desarrollo humano y las expectativas sociales y culturales de ellos. 
        p(data-aos="fade-down") Por su parte, las pautas de crianza son aquellas normas o modelos que guían a los adultos que tienen a cargo el cuidado y la educación de los menores para que, en forma de guía, puedan contribuir con su crecimiento físico, mental, emocional y social.  
        
    .row.mb-5.align-items-center     
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-1.p-4.mb-4(data-aos="fade-up") 
          p(data-aos="fade-down").mb-0 Las pautas de crianza son diferenciales, según el contexto, la historia y las realidades de las familias; por ejemplo, tiempo atrás, se creía que la mejor forma de criar hijos obedientes era a través de los golpes, gritos y castigos. Y aunque efectivamente, en gran parte de los casos, podría funcionar por el instante, estas prácticas llevaron a generaciones educadas a través del temor y miedo por sus mayores o al contrario, actitudes desafiantes y agresivas por parte de los niños. 
        p(data-aos="fade-down") Actualmente, existen múltiples posturas frente a las prácticas adecuadas para lograr una infancia plena y una adultez sana; sin embargo, los tiempos, contextos, culturas e historias, demuestran que lo más importante es considerar la importancia de los entornos saludables, en donde los menores puedan contar con adultos cuidadores, responsables, amorosos y protectores.
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/3.png", data-aos="zoom-in") 
          
    .bg-full-width.bg-color-3.p-4(data-aos="fade-left")
      .row
        .col-lg-auto
          img.img-a.img-t(src="@/assets/curso/temas/4.svg")
        .col-lg.j1
          p.mb-0 Así las cosas, los entornos rurales y las familias campesinas, son un contexto oportuno para que esos niños que habitan lo rural puedan tener una infancia plena, donde la educación y la atención integral sean el medio para lograr una generación de adolescentes jóvenes y adultos ciudadanos generosos, responsables, contemplativos, reflexivos, con proyectos de vida positivos y dispuestos al autocuidado, el cuidado del otro y del planeta. 
</template>
